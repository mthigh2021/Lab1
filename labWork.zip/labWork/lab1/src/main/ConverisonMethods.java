package main;

import java.util.Scanner;

public class ConverisonMethods {
import java.util.Scanner;
	
	
	public static void main (String[] args) {
		
		 int menuSelection;
		 Scanner myScanner = new Scanner(System.in);
		 //String line = myscanner.nextLine();
		 System.out.println("Please choose a number and hit Enter.");
		 System.out.println("1. Cups to Teaspoons");
		 System.out.println("2. Miles to Kilometers");
		 System.out.println("3. US Gallons to Imperial Gallons");
		 System.out.println("4. Quit");
		
		
	}
public void int collectInput(int a) {
	return a;
}
	
	
 public void cupToteaSpoon() {
	 
	 
	 
 }
public void   mileToKiloMeter() {
	
	
}
public void galonToImperialSystem() {
	 
	
}

}
